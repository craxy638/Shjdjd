"Report for spam" "This group is spammer group "
