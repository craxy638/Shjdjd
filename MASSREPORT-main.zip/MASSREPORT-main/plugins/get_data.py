# import asyncio
# import json, os
# from pyrogram import Client, enums
# #loads config

# #workdir = 'session/'disconect
# async def main():
            # function not available yet

            
# asyncio.run(main())
